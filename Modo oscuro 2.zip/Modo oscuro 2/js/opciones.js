let Angel=document.getElementById('Angel');
            Angel.addEventListener("click",function(e){
(async() => {
  
  

const {value: gusto} = await Swal.fire({
  icon: 'success',
  title: 'YO LO INVITO 🙃 ¿NO HAY TUS GOMITAS FAVORITAS?',
  text: ' TRANQUILA AQUÍ HAY SOLUCIÓN MÁNDAME UNA CAPTURA DE TUS GOMITA FAVORITA HACIENDO CLICK EN *ENVIAR*',

  confirmButtonText:	'  	<a href="https://wa.link/va9t85">ENVIAR</a>',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	  input:'select',
	 inputPlaceholder:'Cuantas?',
	  inputValue:'console',
	  inputOptions: {
				1:'1 GOMITA ',
				2: '2 GOMITAS',
				4: '4 GOMITAS',
				5: '5 GOMITAS',
				6: '6 GOMITAS',
				7: '7 GOMITAS',
				8: '8 GOMITAS',
				9: '9 GOMITAS',
				
				
					
	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar',

    showCancelButton: true,
	  cancelButtonText: 'CANCELAR',
	  cancelButtonColor: '#ff0000',
	  cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Angel.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',
 

});
 if (gusto){
  Swal.fire({
    title: `TALㅤVEZㅤQUISISTEㅤDECIRㅤQUEㅤYO: ${none}`
  });
}
})();
});


let Angel2=document.getElementById('Angel2');
            Angel2.addEventListener("click",function(e){
(async() => {
  
  

const {value: gusto} = await Swal.fire({
  icon: 'success',
  title: 'Yo lo invito 🙃 GOMITAS GUANDY CULEBRITAS',
  text: ' Características principales: Contiene 100 gramos, Gomitas de gelatina ácidas',

  confirmButtonText:	' QUIERO ESTO',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	  input:'select',
	 inputPlaceholder:'CUANTAS?',
	 inputValue: '',
	 inputOptions: {
			1:'1 GOMITA ',
				2: '2 GOMITAS',
				4: '4 GOMITAS',
				5: '5 GOMITAS',
				6: '6 GOMITAS',
				7: '7 GOMITAS',
				8: '8 GOMITAS',
				9: '9 GOMITAS',
	},

	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar',

    showCancelButton: true,
	  cancelButtonText: ' NO QUIERO',
	  cancelButtonColor: '#ff0000',
	  cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas1.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',

});
if (gusto){
  Swal.fire({
    title: `BUEN TRABAJO AHORA SOLO QUEDA CONFIRMAR Y PODER OBTENER TU GOMITA ❤️ GOMITAS GUANDY CULEBRITAS ${gusto} GOMITAS`,
    icon:'success',
    text: ' AQUÍ CONFIRMA LA GOMITA QUE ELEGISTE, PULSANDO EN *ENVIAR* ',

  confirmButtonText:	'  	<a href="https://wa.link/va9t85">ENVIAR</a>',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	 // input:'select',
	 // inputPlaceholder:'CUANTAS?',
	 // inputValue: '',
	 // inputOptions: {

	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar Gomita',

   // showCancelButton: true,
	//  cancelButtonText: ' NO QUIERO',
	  // cancelButtonColor: '#ff0000',
	 // cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas1.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',
  });
}
})();
});



let Angel3=document.getElementById('Angel3');
            Angel3.addEventListener("click",function(e){
(async() => {
  
  

const {value: gusto} = await Swal.fire({
  icon: 'success',
  title: 'Yo lo invito 🙃 GOMITAS TROLLI PIZZA',
  text: ' Características principales: Contiene 15.5 gramos, Gomitas con forma de pizza',

  confirmButtonText:	' QUIERO ESTO',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	  input:'select',
	 inputPlaceholder:'CUANTAS?',
	  inputValue: '',
	  inputOptions: {
1:'1 GOMITA ',
				2: '2 GOMITAS',
				4: '4 GOMITAS',
				5: '5 GOMITAS',
				6: '6 GOMITAS',
				7: '7 GOMITAS',
				8: '8 GOMITAS',
				9: '9 GOMITAS',
	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar',

    showCancelButton: true,
	  cancelButtonText: ' NO QUIERO',
	  cancelButtonColor: '#ff0000',
	  cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas2.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',

});
if (gusto){
  Swal.fire({
    title: `BUEN TRABAJO AHORA SOLO QUEDA CONFIRMAR Y PODER COMPRAR TU GOMITA ❤️ ELEGISTE GOMITAS TROLLI PIZZA ${gusto} GOMITAS`,
    icon:'success',
    text: ' AQUÍ CONFIRMA LA GOMITA QUE ELEGISTE, PULSANDO EN *ENVIAR* ',

  confirmButtonText:	'  	<a href="https://wa.link/va9t85">ENVIAR</a>',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	 // input:'select',
	 // inputPlaceholder:'CUANTAS?',
	 // inputValue: '',
	 // inputOptions: {

	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar Gomita',

   // showCancelButton: true,
	//  cancelButtonText: ' NO QUIERO',
	  // cancelButtonColor: '#ff0000',
	 // cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas2.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',
  });
}
})();
});



let Angel4=document.getElementById('Angel4');
            Angel4.addEventListener("click",function(e){
(async() => {
  
  

const {value: gusto} = await Swal.fire({
  icon: 'success',
  title: 'Yo lo invito 🙃 GOMITAS  SAVOR MORA FINI MORAS',
  text: ' Características principales: Contiene 90 gramos, Caramelos de gelatina con sabor artificial a mora Coloreado y aromatizado artificialmente',

  confirmButtonText:	' QUIERO ESTO',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	  input:'select',
	 inputPlaceholder:'CUANTAS?',
	  inputValue: '',
	  inputOptions: {
1:'1 GOMITA ',
				2: '2 GOMITAS',
				4: '4 GOMITAS',
				5: '5 GOMITAS',
				6: '6 GOMITAS',
				7: '7 GOMITAS',
				8: '8 GOMITAS',
				9: '9 GOMITAS',
	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar',

    showCancelButton: true,
	  cancelButtonText: ' NO QUIERO',
	  cancelButtonColor: '#ff0000',
	  cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas3.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',

});
if (gusto){
  Swal.fire({
    title: `BUEN TRABAJO AHORA SOLO QUEDA CONFIRMAR Y PODER COMPRAR TU GOMITA ❤️ GOMITAS  SAVOR MORA FINI MORAS ${gusto} GOMITAS`,
    icon:'success',
    text: ' AQUÍ CONFIRMA LA GOMITA QUE ELEGISTE, PULSANDO EN *ENVIAR* ',

  confirmButtonText:	'  	<a href="https://wa.link/va9t85">ENVIAR</a>',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	 // input:'select',
	// inputPlaceholder:'Que te gusta más',
	 // inputValue: '',
	 // inputOptions: {
				//	TEㅤGUSTO:'GATO 🐈 ',
				//	TEㅤGUSTOO: 'PERRO 🐶',
			//	TEㅤGUSTOOO: 'Hámster 🐹',
			//		TEㅤGUSTOOO0: ' O QUIZÁS YO 😏 ',
				//	SOYㅤELㅤAMORㅤDEㅤTUㅤVIDA: ' NINGUNA DE LAS ANTERIORES ',
//	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar Gomita',

   // showCancelButton: true,
	//  cancelButtonText: ' NO QUIERO',
	  // cancelButtonColor: '#ff0000',
	 // cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas3.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',
  });
}
})();
});





let Angel5=document.getElementById('Angel5');
            Angel5.addEventListener("click",function(e){
(async() => {
  
  

const {value: gusto} = await Swal.fire({
  icon: 'success',
  title: ' Yo lo invito 🙃 GOMITAS TROLLI SHARKS',
  text: ' Características principales: Contiene 100 gramos Caramelos blandos de goma Con forma de tiburones Sin gluten',

  confirmButtonText:	' QUIERO ESTO',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	  input:'select',
	 inputPlaceholder:'CUANTAS?',
	  inputValue: '',
	  inputOptions: {
	    
1:'1 GOMITA ',
				2: '2 GOMITAS',
				4: '4 GOMITAS',
				5: '5 GOMITAS',
				6: '6 GOMITAS',
				7: '7 GOMITAS',
				8: '8 GOMITAS',
				9: '9 GOMITAS',
	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar',

    showCancelButton: true,
	  cancelButtonText: ' NO QUIERO',
	  cancelButtonColor: '#ff0000',
	  cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas4.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',

});
if (gusto){
  Swal.fire({
    title: `BUEN TRABAJO AHORA SOLO QUEDA CONFIRMAR Y PODER OBTENER TU GOMITA ❤️ GOMITAS TROLLI SHARKS  ${gusto} GOMITAS`,
    icon:'success',
    text: ' AQUÍ CONFIRMA LA GOMITA QUE ELEGISTE, PULSANDO EN *ENVIAR* ',

  confirmButtonText:	'  	<a href="https://wa.link/va9t85">ENVIAR</a>',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	 // input:'select',
	// inputPlaceholder:'Que te gusta más',
	 // inputValue: '',
	 // inputOptions: {
				//	TEㅤGUSTO:'GATO 🐈 ',
				//	TEㅤGUSTOO: 'PERRO 🐶',
			//	TEㅤGUSTOOO: 'Hámster 🐹',
			//		TEㅤGUSTOOO0: ' O QUIZÁS YO 😏 ',
				//	SOYㅤELㅤAMORㅤDEㅤTUㅤVIDA: ' NINGUNA DE LAS ANTERIORES ',
//	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar Gomita',

   // showCancelButton: true,
	//  cancelButtonText: ' NO QUIERO',
	  // cancelButtonColor: '#ff0000',
	 // cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas4.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',
  });
}
})();
});




let Angel6=document.getElementById('Angel6');
            Angel6.addEventListener("click",function(e){
(async() => {
  
  

const {value: gusto} = await Swal.fire({
  icon: 'success',
  title: 'Yo lo invito 🙃 GOMITAS TRICOLOR FINI',
  text: ' Características principales: GOMAS TIPO CABLE Y CINTA, SABOR: TRICOLOR',

  confirmButtonText:	' QUIERO ESTO',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	 input:'select',
	 inputPlaceholder:'CUANTAS?',
	 inputValue: '',
	 inputOptions: {
	      1:'1 GOMITA ',
				2: '2 GOMITAS',
				4: '4 GOMITAS',
				5: '5 GOMITAS',
				6: '6 GOMITAS',
				7: '7 GOMITAS',
				8: '8 GOMITAS',
				9: '9 GOMITAS',

	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar',

    showCancelButton: true,
	  cancelButtonText: ' NO QUIERO',
	  cancelButtonColor: '#ff0000',
	  cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas9.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',

});
if (gusto){
  Swal.fire({
    title: `BUEN TRABAJO AHORA SOLO QUEDA CONFIRMAR Y PODER OBTENER TU GOMITA ❤️ ELEGISTE GOMITAS TRICOLOR FINI ${gusto} GOMITAS`,
    icon:'success',
    text: ' AQUÍ CONFIRMA LA GOMITA QUE ELEGISTE, PULSANDO EN *ENVIAR* ',

  confirmButtonText:	'  	<a href="https://wa.link/va9t85">ENVIAR</a>',
  footer:'<span class="rojo"> ESCOGE SU GOMITA FAVORITA ✨',
  background:'#000',
  
 // timerProgressBar:
	// toast:
	 position: 'center',
	 allowOutsideClick: false,
	 allowEscapeKey: false,
  allowEnterKey: false,
	 stopKeydownPropagation: false,
	
	 // input:'select',
	// inputPlaceholder:'Que te gusta más',
	 // inputValue: '',
	 // inputOptions: {
				//	TEㅤGUSTO:'GATO 🐈 ',
				//	TEㅤGUSTOO: 'PERRO 🐶',
			//	TEㅤGUSTOOO: 'Hámster 🐹',
			//		TEㅤGUSTOOO0: ' O QUIZÁS YO 😏 ',
				//	SOYㅤELㅤAMORㅤDEㅤTUㅤVIDA: ' NINGUNA DE LAS ANTERIORES ',
//	},
	
 customClass: {
 
	// 	container:
	 	popup: 'popup-class'
	// 	header:
	// 	title:
	// 	closeButton:
	// 	icon:
	// 	image:
	// 	content:
	// 	input:
	// 	actions:
	// 	confirmButton:
	// 	cancelButton:
	// 	footer:
	},
	
	
		 showConfirmButton: true,
	  confirmButtonColor: '#ff1515',
	  confirmButtonAriaLabel:'Confirmar Gomita',

   // showCancelButton: true,
	//  cancelButtonText: ' NO QUIERO',
	  // cancelButtonColor: '#ff0000',
	 // cancelButtonAriaLabel: ' NO QUIERO',
	
	// buttonsStyling:
	// showCloseButton:
	// closeButtonAriaLabel:

 imageUrl: 'Gomitas9.jpg',
 imageWidth: '300px',
	// imageHeight:
 imageAlt: 'imagen de una diosa',
  });
}
})();
});